/*
 * Do not remove this file. This file is to make Xcode to link with C++ Runtime
 * Library automatically.
 */
