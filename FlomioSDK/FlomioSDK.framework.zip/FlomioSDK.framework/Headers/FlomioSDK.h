//
//  FlomioSDK.h
//  FlomioSDK
//¡
//  Created by Scott Condron on 18/01/2018.
//  Copyright © 2018 Flomio, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FlomioSDK.
FOUNDATION_EXPORT double FlomioSDKVersionNumber;

//! Project version string for FlomioSDK.
FOUNDATION_EXPORT const unsigned char FlomioSDKVersionString[];

#import "FmSessionManager.h"

